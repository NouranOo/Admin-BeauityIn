<?php $__env->startSection('title'); ?>
    Users
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="col-sm-12 page-heading">
        <div class="col-sm-6">
            <h2>Providers</h2>
        </div><!--End col-md-6-->
        <div class="col-sm-6">
            <ul class="breadcrumb">
                
                
            </ul>
        </div><!--End col-md-6-->
    </div>
    <div class="spacer-15"></div>
    <div class="widget">
         <div class="widget-content">
            <div class="table-responsive">
                <table id="datatable"  class="table table-bordered table-hover table-cen">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>إسم المستخدم</th>
                            <th>البريد الألكترونى</th>
                              <th>رقم الموبيل </th>
                             <th>اسم المكان </th>
                             
                           
                           
                        </tr>
                    </thead>
                    <tbody>
                        <?php ($i = 1); ?>
                        <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="tr_<?php echo e($one->id); ?>">
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($one->name); ?></td>
                            <td><?php echo e($one->email); ?></td>
                            <td><?php echo e($one->phone); ?></td>
                            <td><?php echo e($one->place_name); ?></td>
                             
                            
                         </tr>
                        <?php ($i++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>