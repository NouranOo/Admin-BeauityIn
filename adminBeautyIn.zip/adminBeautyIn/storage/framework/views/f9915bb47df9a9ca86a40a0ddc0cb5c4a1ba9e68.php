<div class="side-menu">
    <div class="logo">
        
    </div><!--End Logo-->
    <aside class="sidebar">
        <ul class="side-menu-links">
            <li class="<?php if(Request::url() == 'dashboard'): ?><?php echo e('active'); ?><?php endif; ?>"><a href="<?php echo e(url('dashboard')); ?>">DashBoard</a></li>
            
            
                
                <ul>
                    
                    
                </ul>
            </li>
            
            <li class="<?php if(Request::url() == 'getAdmin'): ?><?php echo e('active'); ?><?php endif; ?>"><a href="<?php echo e(url ('getAdmin')); ?>">Admins</a></li>
            <li class="<?php if(Request::url()  == 'getUser'): ?><?php echo e('active'); ?><?php endif; ?>"><a href="<?php echo e(url('getUser')); ?>">Users</a></li> 
            <li class="<?php if(Request::url() == ' getProvider'): ?><?php echo e('active'); ?><?php endif; ?>"><a href="<?php echo e(url('getProvider')); ?>">Providers</a></li>
            <li class="<?php if(Request::url() == 'getService'): ?><?php echo e('active'); ?><?php endif; ?>"><a href="<?php echo e(url ('getService')); ?>">Services</a></li>
            <li class="<?php if(Request::url()  == 'getSubService'): ?><?php echo e('active'); ?><?php endif; ?>"><a href="<?php echo e(url('getSubService')); ?>">Sub Services</a></li>
            <li class="<?php if(Request::url()  == 'getOrder'): ?><?php echo e('active'); ?><?php endif; ?>"><a href="<?php echo e(url('getOrder')); ?>">Orders</a></li>

        </ul>
    </aside>
</div>