<div class="top-header">
    <div class="toggle-icon"  data-toggle="tooltip" data-placement="right" title="Toggle Menu">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <ul class="top-header-links">
        <li class="profile">
            <a class="custom-btn">
                
                
            </a>
        </li>
        <li>
            <a href="<?php echo e(url ('login')); ?>">
                <i class="fa fa-power-off"></i>
                Logout
            </a>
        </li>
    </ul>
</div>