<?php $__env->startSection('title'); ?>
    Sub Services
<?php $__env->stopSection(); ?>
<?php $__env->startSection('models'); ?>
<div class="modal fade" id="add_subService" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content text-center">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add new Sub-Service</h5>
            </div>
            <form action="<?php echo e(url ('addSubService')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">

                    <div class="alert alert-success hidden SuccessMessage" ></div>
                    <div class="alert alert-danger hidden ErrorMessage" ></div>
                    <?php echo csrf_field(); ?>

                    <div class="col-md-6 form-group">
                            <label>Service name</label>
                    <select name="service_id" class="form-control">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <option value="<?php echo e($service->id); ?>" ><?php echo e($service->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>                      
                  </div> 

                    <div class="col-md-6 form-group">
                        <label>Sub-Service name</label>
                        <input class="form-control" placeholder="name" type="text" required name="name">
                    </div>
                    

                </div>
                <div class="modal-footer text-center">
                    <button type="submit" class="custom-btn green-bc ">add</button>
                    <button type="button" class="custom-btn red-bc" data-dismiss="modal">close</button>
                </div>
            </form>
        </div>
    </div>
</div>

    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="col-sm-12 page-heading">
        <div class="col-sm-6">
            <h2>Services</h2>
        </div><!--End col-md-6-->
        <div class="col-sm-6">
            <ul class="breadcrumb">
                
                
            </ul>
        </div><!--End col-md-6-->
    </div>
    <div class="col-sm-12">
        <button  data-toggle="modal" data-target="#add_subService" action="<?php echo e(url('addSubService')); ?>" class="custom-btn green-bc">
            <i class="fa fa-plus"></i>
            Add Sub-Service
        </button>
    </div>
    <div class="spacer-15"></div>
    <div class="widget">
         <div class="widget-content">
            <div class="table-responsive">
                <table id="datatable"  class="table table-bordered table-hover table-cen">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>إسم الخدمة</th>
                            
                              
                             
                           
                           
                        </tr>
                    </thead>
                    <tbody>
                        <?php ($i = 1); ?>
                        <?php $__currentLoopData = $subServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="tr_<?php echo e($one->id); ?>">
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($one->name); ?></td>
                            
                            
                             
                            
                         </tr>
                        <?php ($i++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>